README

Project 2 - BST and AVL Trees
Author: Manthra Natarajan

Files:
- BinarySearchTree.java: Contains the base binary search tree implementation.
- AVLTree.java: Extends BinarySearchTree to implement an AVL tree with self-balancing functionality.
- readme.txt: Provides instructions for compiling and running the code.

Compilation:
1. Open a terminal or command prompt.
2. Navigate to the directory containing the source files (`BinarySearchTree.java` and `AVLTree.java`).
3. Run the following command to compile both files:

Instructions:
1. Opening the Project
   - Open your Java IDE
   - Create a new Java Project, or open an existing one.
   - Add the provided files (`BinarySearchTree.java`, `AVLTree.java`) to the project by copying them into the `src` folder or importing them.

2. Running the Code
   - Navigate to the AVLTreeDriver class, and run that main method.
   - Add your inputs, hit ENTER after each input, then type End when finished.
   - Press ENTER
   - The program should execute, and you can view the output in the console window of your IDE.